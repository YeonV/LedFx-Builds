// LedFx Workspace Setup Script (Node.js)
// Clones all required repositories into their respective folders

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const repos = [
  {
    folder: 'frontend',
    url: 'https://github.com/YeonV/LedFx-Frontend-v2.git'
  },
  {
    folder: 'backend',
    url: 'https://github.com/LedFx/LedFx.git'
  },
  {
    folder: '_audio-visualiser',
    url: 'https://github.com/Mattallmighty/audio-visualiser.git',
    upstream: 'https://github.com/YeonV/audio-visualiser.git'
  },
  {
    folder: '_react-dynamic-module',
    url: 'https://github.com/YeonV/react-dynamic-module.git'
  },
  {
    folder: '_pipeline/tools/song_detector',
    url: 'https://github.com/YeonV/LedFx-Builds.git'
  },
  {
    folder: '_python-for-android',
    url: 'https://github.com/YeonV/python-for-android.git',
    upstream: 'https://github.com/broccoliboy/python-for-android.git'
  },
  {
    folder: '_pipeline_android',
    url: 'https://github.com/YeonV/ledfx-android.git',
    upstream: 'https://github.com/broccoliboy/ledfx-android.git'
  },
  {
    folder: '_download',
    url: 'https://github.com/YeonV/LedFx-Builds.git'
  },
  {
    folder: '_pipeline',
    url: 'https://github.com/YeonV/ledfx-web.git'
  }
];

const readline = require('readline');

function cloneRepo(folder, url, upstream) {
  if (!fs.existsSync(folder)) {
    console.log(`Cloning ${url} into ${folder}...`);
    // Ensure parent directory exists
    const parent = path.dirname(folder);
    if (parent !== '.' && !fs.existsSync(parent)) {
      fs.mkdirSync(parent, { recursive: true });
    }
    execSync(`git clone ${url} ${folder}`, { stdio: 'inherit' });
    if (upstream) {
      try {
        execSync(`git remote add upstream ${upstream}`, { cwd: folder, stdio: 'inherit' });
        console.log(`Added upstream remote (${upstream}) to ${folder}`);
      } catch (e) {
        console.log(`Failed to add upstream remote to ${folder}:`, e.message);
      }
    }
  } else {
    console.log(`Folder ${folder} already exists, skipping.`);
  }
}

// Interactive menu and auto-run logic

function showMenuAndClone() {
  const stdin = process.stdin;
  const stdout = process.stdout;
  let selected = repos.map(() => false);
  let cursor = 0;
  let timer;

  function renderMenu() {
    stdout.write('\x1Bc'); // clear screen
    stdout.write('Select repos to clone (SPACE to toggle, ENTER to confirm):\n');
    repos.forEach((repo, idx) => {
      const name = repo.folder || repo.url.split('/').pop().replace('.git', '');
      const prefix = cursor === idx ? '> ' : '  ';
      const mark = selected[idx] ? '[x]' : '[ ]';
      stdout.write(`${prefix}${mark} ${name}\n`);
    });
    stdout.write('\nUse UP/DOWN to navigate, SPACE to select, ENTER to confirm.\n');
  }

  function startAutoRun() {
    timer = setTimeout(() => {
      stdout.write('\nNo input detected. Auto-running cloning for all repos...\n');
      runCloning(repos);
      stdin.setRawMode(false);
      stdin.pause();
    }, 3000);
  }

  function stopAutoRun() {
    if (timer) clearTimeout(timer);
  }

  stdin.setRawMode(true);
  stdin.resume();
  stdin.setEncoding('utf8');
  renderMenu();
  startAutoRun();

  stdin.on('data', function(key) {
    stopAutoRun();
    if (key === '\u0003') { // Ctrl+C
      process.exit();
    } else if (key === '\r') { // ENTER
      stdin.setRawMode(false);
      stdin.pause();
      let chosen = selected.some(s => s) ? repos.filter((_, idx) => selected[idx]) : repos;
      runCloning(chosen);
    } else if (key === '\u001b[A') { // UP
      cursor = (cursor - 1 + repos.length) % repos.length;
      renderMenu();
      startAutoRun();
    } else if (key === '\u001b[B') { // DOWN
      cursor = (cursor + 1) % repos.length;
      renderMenu();
      startAutoRun();
    } else if (key === ' ') { // SPACE
      selected[cursor] = !selected[cursor];
      renderMenu();
      startAutoRun();
    }
  });
}

function runCloning(selectedRepos) {
  selectedRepos.forEach(repo => {
    cloneRepo(repo.folder, repo.url, repo.upstream);
  });

  // Dynamic workspace file generation
  const workspaceFile = 'ledfx.code-workspace';
  // Folder templates
  const folderTemplates = {
    'frontend': { path: 'frontend', name: '[Frontend] Web + CC', settings: { 'npm.packageManager': 'yarn' } },
    'backend': { path: 'backend', name: '[Backend] Core' },
    '_audio-visualiser': { path: '_audio-visualiser', name: '[Visualiser]', settings: { 'npm.packageManager': 'pnpm' } },
    '_react-dynamic-module': { path: '_react-dynamic-module', name: '[Dynamic Module]', settings: { 'npm.packageManager': 'yarn' } },
    '_pipeline/tools/song_detector': { path: '_pipeline/tools/song_detector', name: '[Song Detector]' },
    '_pipeline': { path: '_pipeline', name: '[Build]' },
    '_pipeline_android': { path: '_pipeline_android', name: '[Build Android]' },
    '_python-for-android': { path: '_python-for-android', name: '[Python For Android]' },
    '_download': { path: '_download', name: '[Download Page]', settings: { 'npm.packageManager': 'yarn' } }
  };

  // Task templates
  const taskTemplates = [
    {
      label: 'Init Workspace (clone all repos)',
      type: 'shell',
      command: 'node',
      args: ['ledfx.setup.js'],
      options: { cwd: '${workspaceFolder}' },
      presentation: { reveal: 'always' },
      group: 'build'
    },
    {
      label: '[Backend] Start',
      type: 'shell',
      command: 'uv',
      args: ['run', 'ledfx', '--offline', '-vv'],
      options: { cwd: '${workspaceFolder:backend}' },
      presentation: { reveal: 'always' },
      group: 'build'
    },
    {
      label: '[Frontend] Start',
      type: 'shell',
      command: 'yarn',
      args: ['start'],
      options: { cwd: '${workspaceFolder:frontend}' },
      presentation: { reveal: 'always' },
      group: 'build'
    },
    {
      label: '[Backend] Init',
      type: 'shell',
      command: 'uv',
      args: ['install', 'ledfx'],
      options: { cwd: '${workspaceFolder:backend}' },
      presentation: { reveal: 'always' },
      group: 'build'
    },
    {
      label: '[Frontend] Init',
      type: 'shell',
      command: 'yarn',
      options: { cwd: '${workspaceFolder:frontend}' },
      presentation: { reveal: 'always' },
      group: 'build'
    },
    {
      label: '[Visualiser] Init',
      type: 'shell',
      command: 'pnpm',
      args: ['install'],
      options: { cwd: '${workspaceFolder:_audio-visualiser}' },
      presentation: { reveal: 'always' },
      group: 'build'
    },
    {
      label: '[Visualiser] Start',
      type: 'shell',
      command: 'pnpm',
      args: ['dev'],
      options: { cwd: '${workspaceFolder:_audio-visualiser}' },
      presentation: { reveal: 'always' },
      group: 'build'
    }
  ];

  // Build folders array based on selected repos
  const selectedFolders = selectedRepos.map(repo => folderTemplates[repo.folder]).filter(Boolean);

  // Filter tasks to only include those relevant to selected folders
  const selectedFolderNames = selectedFolders.map(f => f.path);
  const filteredTasks = taskTemplates.filter(task => {
    if (task.options && task.options.cwd) {
      // Extract folder name from workspace variable
      const match = task.options.cwd.match(/\$\{workspaceFolder:([^}]+)}/);
      if (match) {
        return selectedFolderNames.includes(match[1]);
      }
      // If not a folder-specific task, include
      return true;
    }
    return true;
  });

  // Add RE-Init task as last point
  filteredTasks.push({
    label: 'RE-Init Workspace (clone missing repos)',
    type: 'shell',
    command: 'node',
    args: ['ledfx.setup.js'],
    options: { cwd: '${workspaceFolder}' },
    presentation: { reveal: 'always' },
    group: 'build'
  });

  const dynamicWorkspaceContent = {
    folders: selectedFolders,
    settings: {},
    tasks: {
      version: '2.0.0',
      tasks: filteredTasks
    }
  };
  fs.writeFileSync(workspaceFile, JSON.stringify(dynamicWorkspaceContent, null, 2));
  console.log('Workspace file dynamically generated for selected repos.');
}

// Start menu
showMenuAndClone();
